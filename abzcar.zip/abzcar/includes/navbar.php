<nav>
    <ul>
        <li><a href="/index.php">Inicio</a></li>
        <li><a href="/servicios.php">Servicios</a></li>
        <li><a href="/proyectos.php">Proyectos</a></li>
        <li><a href="/testimonios.php">Testimonios</a></li>
        <li><a href="/faqs.php">FAQs</a></li>
        <li><a href="/contacto.php">Contacto</a></li>
    </ul>
</nav> 