// Script principal de ABZCAR
console.log('Sitio ABZCAR cargado correctamente.'); 