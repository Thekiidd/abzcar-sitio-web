# ABZCAR - Sitio Web Corporativo

Sitio web informativo para la empresa ABZCAR, dedicada a servicios de mecánica automotriz y grúas.

## Características

- **Diseño Responsive**: Compatible con dispositivos móviles, tablets y computadoras
- **Base de Datos MySQL**: Gestión dinámica de contenido
- **Panel de Administración**: Interfaz para gestionar servicios, testimonios, proyectos y FAQs
- **Formulario de Contacto**: Sistema de contacto funcional
- **Tecnologías Modernas**: HTML5, CSS3, JavaScript, PHP

## Estructura del Proyecto

```
abzcar/
├── assets/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── main.js
│   ├── images/
│   └── fonts/
├── includes/
│   ├── header.php
│   ├── navbar.php
│   └── footer.php
├── config/
│   └── config.php
├── database/
│   └── init.sql
├── admin/
│   ├── index.php
│   ├── servicios.php
│   ├── testimonios.php
│   ├── proyectos.php
│   ├── faqs.php
│   └── contactos.php
├── index.php
├── servicios.php
├── proyectos.php
├── testimonios.php
├── faqs.php
├── contacto.php
└── README.md
```

## Instalación

### Requisitos Previos

- XAMPP (Apache + MySQL + PHP)
- Navegador web moderno

### Pasos de Instalación

1. **Clonar/Descargar el proyecto**
   - Colocar todos los archivos en la carpeta `htdocs/abzcar/` de XAMPP

2. **Configurar la Base de Datos**
   - Abrir phpMyAdmin (http://localhost/phpmyadmin)
   - Crear una nueva base de datos llamada `abzcar`
   - Importar el archivo `database/init.sql` para crear las tablas

3. **Configurar la Conexión**
   - Editar `config/config.php` si es necesario:
     ```php
     $host = 'localhost';
     $user = 'root';
     $password = '';
     $db = 'abzcar';
     ```

4. **Iniciar Servicios**
   - Iniciar Apache y MySQL en XAMPP
   - Acceder al sitio: http://localhost/abzcar/

## Uso

### Sitio Web Público

- **Inicio**: http://localhost/abzcar/
- **Servicios**: http://localhost/abzcar/servicios.php
- **Proyectos**: http://localhost/abzcar/proyectos.php
- **Testimonios**: http://localhost/abzcar/testimonios.php
- **FAQs**: http://localhost/abzcar/faqs.php
- **Contacto**: http://localhost/abzcar/contacto.php

### Panel de Administración

- **Acceso**: http://localhost/abzcar/admin/
- **Funcionalidades**:
  - Gestionar Servicios
  - Gestionar Testimonios
  - Gestionar Proyectos
  - Gestionar FAQs
  - Ver Contactos Recibidos

## Base de Datos

### Tablas Principales

1. **servicios**: Almacena los servicios ofrecidos
   - id, nombre, descripcion, categoria

2. **testimonios**: Comentarios de clientes
   - id, nombre_cliente, comentario, fecha

3. **contactos**: Formularios de contacto
   - id, nombre, correo, telefono, mensaje, fecha

4. **proyectos**: Trabajos realizados
   - id, titulo, descripcion, imagen, fecha

5. **faqs**: Preguntas frecuentes
   - id, pregunta, respuesta

## Personalización

### Estilos CSS
- Editar `assets/css/style.css` para modificar la apariencia
- El diseño es responsive y se adapta a diferentes dispositivos

### Contenido
- Usar el panel de administración para gestionar contenido dinámico
- Los cambios se reflejan automáticamente en el sitio web

## Despliegue en Hostinger

1. **Subir archivos** via FTP al directorio público
2. **Crear base de datos** en el panel de Hostinger
3. **Importar** `database/init.sql`
4. **Actualizar** `config/config.php` con las credenciales de Hostinger
5. **Configurar** dominio y SSL si es necesario

## Soporte

Para soporte técnico o consultas sobre el proyecto, contactar al desarrollador.

## Licencia

Este proyecto fue desarrollado específicamente para ABZCAR. 